//Mouse.java
package packMouse;
public class Mouse{
	public String name;
	public Mouse(String str){
		name = str;
	}
	public void run(){
		System.out.println("I can run!");
 	}
}
