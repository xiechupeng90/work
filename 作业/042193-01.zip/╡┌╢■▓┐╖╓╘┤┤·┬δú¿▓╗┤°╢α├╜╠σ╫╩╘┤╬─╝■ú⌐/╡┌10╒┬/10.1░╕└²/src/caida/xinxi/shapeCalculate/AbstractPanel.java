package caida.xinxi.shapeCalculate;

import javax.swing.JPanel;
import javax.swing.JTextField;

public abstract class AbstractPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public abstract JTextField getInputTextField();

}
