package client;

import java.awt.*;
import javax.swing.*;

public class MainI extends JFrame {

	public MainI() {
		super("������");
		setSize(200,150);
	}
}
